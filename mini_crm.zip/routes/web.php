<?php

use Illuminate\Support\Facades\Route;




use App\Http\Controllers\AdminController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\EmployeeController
;

use App\Http\Controllers\CustomerController;


Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::post('/admin/employee', [AdminController::class, 'addEmployee'])->name('admin.add.employee');
    Route::post('/admin/assign-customer', [AdminController::class, 'assignCustomer'])->name('admin.assign.customer');
Route::post('/admin/customer', [AdminController::class, 'addCustomer'])->name('admin.add.customer');
    Route::get('/admin/customers', [AdminController::class, 'customers'])->name('admin.customers');
    Route::get('/admin/employees', [AdminController::class, 'employees'])->name('admin.employees');
        Route::post('/add-action/{customer}', [AdminController::class, 'addAction'])->name('admin.add.action');

});


Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::get('/register', function () {
    return view('auth.register');
})->name('register');
// Protected route
Route::middleware(['auth'])->group(function () {
Route::post('/customer/add', [CustomerController::class, 'store'])->name('employee.add.customer');
Route::get('/employee', [EmployeeController::class, 'dashboard'])->name('employee.dashboard');
Route::post('/employee/customer/{customerId}/add-action', [EmployeeController::class, 'addAction'])->name('employee.add.action');

Route::post('/employee/customers', [EmployeeController::class, 'addCustomer'])->name('employee.add.customer');


});
