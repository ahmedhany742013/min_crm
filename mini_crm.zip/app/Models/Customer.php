<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{

    protected $fillable = ['name', 'email', 'phone', 'employee_id'];

    public function employee()
{
    return $this->belongsTo(Employee::class);
}

public function actions()
{
    return $this->hasMany(Action::class);
}

}
