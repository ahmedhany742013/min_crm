<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Customer;
use App\Models\Employee;
use Illuminate\Support\Facades\Auth;

class EmployeeController extends Controller
{


public function dashboard()
{
    $employee = Auth::user()->employee;
    $customers = Customer::where('employee_id', $employee->id)->get();

    return view('employee.dashboard', compact('customers'));
}

public function addCustomer(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'nullable|email|unique:customers,email',  // Ensure email is unique in the 'customers' table
        'phone' => 'nullable|unique:customers,phone',  // Ensure phone is unique in the 'customers' table
    ]);

    $employee = Auth::user()->employee;

    // Create the new customer record
    Customer::create([
        'name' => $request->name,
        'email' => $request->email,
        'phone' => $request->phone,
        'employee_id' => $employee->id,
    ]);

    return back()->with('success', 'Customer added successfully!');
}

// In EmployeeController.php

public function addAction(Request $request, $customerId)
{
    $request->validate([
        'action_type' => 'required|in:call,visit,follow_up',
        'action_result' => 'required|string|max:255',
    ]);

    $customer = Customer::findOrFail($customerId);

    // Save the action
    $customer->actions()->create([
        'action_type' => $request->action_type,
        'action_result' => $request->action_result,
        'employee_id' => auth()->user()->employee->id, // Assuming Employee is related to User
    ]);

    return redirect()->back()->with('success', 'Action recorded successfully!');
}

}
