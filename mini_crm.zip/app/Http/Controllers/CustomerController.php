<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Customer;
use App\Models\Employee;

class CustomerController extends Controller
{


public function assignCustomer(Request $request)
{
    $customer = Customer::find($request->customer_id);

    if (!$customer) {
        return redirect()->back()->withErrors(['Customer not found']);
    }

    $customer->employee_id = $request->employee_id;
    $customer->save();

    return redirect()->back()->with('success', 'Customer assigned successfully.');
}





    public function store(Request $request)
{
    $employee = auth()->user()->employee;

    Customer::create([
        'name' => $request->name,
        'email' => $request->email,
        'phone' => $request->phone,
        'employee_id' => $employee->id,
    ]);

    return back();
}
}
