<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Customer;
use App\Models\Employee;
use App\Models\Action;
use Illuminate\Http\Request;

class AdminController extends Controller
{
public function dashboard()
{
    $employees = \App\Models\Employee::with('user')->get();
    $customers = \App\Models\Customer::with('employee.user')->get();

    return view('admin.dashboard', compact('employees', 'customers'));
}

    public function addEmployee(Request $request)
    {
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt('12345678'),
            'role' => 'employee',
        ]);

        Employee::create(['user_id' => $user->id]);
        return back();
    }

    public function assignCustomer(Request $request)
    {
        $customer = Customer::find($request->customer_id);
        $customer->employee_id = $request->employee_id;
        $customer->save();
        return back();
    }

    public function addCustomer(Request $request)
{
    $request->validate([
        'name' => 'required|string',
        'email' => 'nullable|email',
        'phone' => 'nullable|string',
    ]);

    \App\Models\Customer::create([
        'name' => $request->name,
        'email' => $request->email,
        'phone' => $request->phone,
    ]);

    return back()->with('success', 'Customer added successfully.');
}
public function addAction(Request $request, $customerId)
{
    $request->validate([
        'action_type' => 'required|in:call,visit,follow_up',
        'action_result' => 'required|string',
    ]);

    $customer = Customer::findOrFail($customerId);

    Action::create([
        'customer_id' => $customer->id,
        'employee_id' => auth()->user()->employee->id, // Assuming each employee is logged in
        'type' => $request->action_type,
        'result' => $request->action_result,
    ]);

    return back()->with('success', 'Action recorded successfully!');
}

}
