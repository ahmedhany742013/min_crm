<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f4f4f4;
        }

        h1 {
            color: #333;
        }

        .section {
            background: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 8px;
            max-width: 800px;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        input[type="text"],
        input[type="email"],
        select,
        textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #3490dc;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2779bd;
        }

        .message {
            color: green;
        }

        .errors {
            color: red;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th, table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #eaeaea;
        }

        .action-records {
            background-color: #f9f9f9;
            border-radius: 5px;
            padding: 10px;
            margin-top: 15px;
        }

        .action-records ul {
            list-style-type: none;
            padding-left: 0;
        }

        .action-records li {
            background-color: #eaeaea;
            padding: 8px;
            margin-bottom: 5px;
            border-radius: 5px;
        }

        .action-records li span {
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Admin Dashboard</h1>
    <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
        <?php echo csrf_field(); ?>
        <button type="submit" style="padding: 8px 15px; background-color: #e74c3c; color: white; border: none; border-radius: 5px; cursor: pointer;">
            Logout
        </button>
    </form>

    
    <?php if(session('success')): ?>
        <p class="message"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="errors">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>⚠️ <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <div class="section">
        <h2>Add Employee</h2>
        <form method="POST" action="<?php echo e(route('admin.add.employee')); ?>">
            <?php echo csrf_field(); ?>
            <label>Employee Name:</label>
            <input type="text" name="name" required>

            <label>Employee Email:</label>
            <input type="email" name="email" required>

            <button type="submit">➕ Add Employee</button>
        </form>
    </div>

    
    <div class="section">
        <h2>Add Customer</h2>
        <form method="POST" action="<?php echo e(route('admin.add.customer')); ?>">
            <?php echo csrf_field(); ?>
            <label>Customer Name:</label>
            <input type="text" name="name" required>

            <label>Customer Email:</label>
            <input type="email" name="email">

            <label>Customer Phone:</label>
            <input type="text" name="phone">

            <button type="submit">➕ Add Customer</button>
        </form>
    </div>

    
    <div class="section">
        <h2>Assign Customer to Employee</h2>
        <form method="POST" action="<?php echo e(route('admin.assign.customer')); ?>">
            <?php echo csrf_field(); ?>

            <label>Select Customer:</label>
            <select name="customer_id" required>
                <option value="">-- Choose Customer --</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label>Select Employee:</label>
            <select name="employee_id" required>
                <option value="">-- Choose Employee --</option>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit">📎 Assign Customer</button>
        </form>
    </div>

    
    <div class="section">
        <h2>All Employees</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($employee->user->name); ?></td>
                        <td><?php echo e($employee->user->email); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3">No employees found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="section">
        <h2>All Customers</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Assigned Employee</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td>
                            <?php if($customer->employee): ?>
                                <?php echo e($customer->employee->user->name); ?>

                            <?php else: ?>
                                <em>Not Assigned</em>
                            <?php endif; ?>
                        </td>
                        <td>
                            
                    

                            
                            <div class="action-records">
                                <h4>Recent Actions</h4>
                                <ul>
                                    <?php $__currentLoopData = $customer->actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <span><?php echo e(ucfirst($action->action_type)); ?>:</span> <?php echo e($action->action_result); ?> <br>
                                            <small>Recorded on: <?php echo e($action->created_at->format('d M Y, h:i A')); ?></small>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6">No customers found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\mini_crm\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>