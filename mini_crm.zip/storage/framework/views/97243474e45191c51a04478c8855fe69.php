<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f9f9f9;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2, h3 {
            color: #3490dc;
        }

        input[type="text"],
        input[type="email"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            padding: 10px 15px;
            background-color: #3490dc;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2779bd;
        }

        .action-section {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 30px;
        }

        .actions-list {
            list-style-type: none;
            padding-left: 0;
        }

        .actions-list li {
            background: #eaeaea;
            padding: 10px;
            margin-bottom: 8px;
            border-radius: 5px;
        }

        .actions-list li span {
            font-weight: bold;
        }

        .logout-btn {
            background-color: #e74c3c;
            padding: 10px 15px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            margin-top: 20px;
            display: block;
            width: 100px;
            margin-left: auto;
            margin-right: auto;
        }

        .logout-btn:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Welcome, <?php echo e(auth()->user()->name); ?></h1>

        <!-- Logout Button -->
        <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
        <?php echo csrf_field(); ?>
        <button type="submit" style="padding: 8px 15px; background-color: #e74c3c; color: white; border: none; border-radius: 5px; cursor: pointer;">
            Logout
        </button>
    </form>
        <!-- Add New Customer -->
        <h2>Add Customer</h2>
        <form method="POST" action="<?php echo e(route('employee.add.customer')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" placeholder="Customer Name" required>
            <input type="email" name="email" placeholder="Customer Email" required>
            <input type="text" name="phone" placeholder="Customer Phone" required>
            <button type="submit">➕ Add Customer</button>
        </form>

        <!-- My Customers Section -->
        <h2>My Customers</h2>
        <ul>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <strong><?php echo e($customer->name); ?></strong> | <?php echo e($customer->email); ?> | <?php echo e($customer->phone); ?>


                    <!-- Actions -->
                    <div class="action-section">
                        <h3>Actions</h3>
                        <form method="POST" action="<?php echo e(route('employee.add.action', $customer->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <select name="action_type" required>
                                <option value="">-- Choose Action --</option>
                                <option value="call">Call</option>
                                <option value="visit">Visit</option>
                                <option value="follow_up">Follow Up</option>
                            </select>

                            <textarea name="action_result" placeholder="Enter results..." required></textarea>

                            <button type="submit">➕ Add Action</button>
                        </form>

                        <!-- Display Customer Actions -->
                        <h4>Recent Actions</h4>
                        <ul class="actions-list">
                            <?php $__currentLoopData = $customer->actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <span><?php echo e(ucfirst($action->action_type)); ?>:</span> <?php echo e($action->action_result); ?> <br>
                                    <small>Recorded on: <?php echo e($action->created_at->format('d M Y, h:i A')); ?></small>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\mini_crm\resources\views/employee/dashboard.blade.php ENDPATH**/ ?>