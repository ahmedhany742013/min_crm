<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f4f4f4;
        }

        h1 {
            color: #333;
        }

        .section {
            background: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 8px;
            max-width: 800px;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        input[type="text"],
        input[type="email"],
        select,
        textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #3490dc;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2779bd;
        }

        .message {
            color: green;
        }

        .errors {
            color: red;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th, table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #eaeaea;
        }

        .action-records {
            background-color: #f9f9f9;
            border-radius: 5px;
            padding: 10px;
            margin-top: 15px;
        }

        .action-records ul {
            list-style-type: none;
            padding-left: 0;
        }

        .action-records li {
            background-color: #eaeaea;
            padding: 8px;
            margin-bottom: 5px;
            border-radius: 5px;
        }

        .action-records li span {
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Admin Dashboard</h1>
    <form method="POST" action="{{ route('logout') }}" style="display: inline;">
        @csrf
        <button type="submit" style="padding: 8px 15px; background-color: #e74c3c; color: white; border: none; border-radius: 5px; cursor: pointer;">
            Logout
        </button>
    </form>

    {{-- Success Message --}}
    @if (session('success'))
        <p class="message">{{ session('success') }}</p>
    @endif

    {{-- Error Message --}}
    @if ($errors->any())
        <div class="errors">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>⚠️ {{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    {{-- Add Employee --}}
    <div class="section">
        <h2>Add Employee</h2>
        <form method="POST" action="{{ route('admin.add.employee') }}">
            @csrf
            <label>Employee Name:</label>
            <input type="text" name="name" required>

            <label>Employee Email:</label>
            <input type="email" name="email" required>

            <button type="submit">➕ Add Employee</button>
        </form>
    </div>

    {{-- Add Customer --}}
    <div class="section">
        <h2>Add Customer</h2>
        <form method="POST" action="{{ route('admin.add.customer') }}">
            @csrf
            <label>Customer Name:</label>
            <input type="text" name="name" required>

            <label>Customer Email:</label>
            <input type="email" name="email">

            <label>Customer Phone:</label>
            <input type="text" name="phone">

            <button type="submit">➕ Add Customer</button>
        </form>
    </div>

    {{-- Assign Customer --}}
    <div class="section">
        <h2>Assign Customer to Employee</h2>
        <form method="POST" action="{{ route('admin.assign.customer') }}">
            @csrf

            <label>Select Customer:</label>
            <select name="customer_id" required>
                <option value="">-- Choose Customer --</option>
                @foreach ($customers as $customer)
                    <option value="{{ $customer->id }}">{{ $customer->name }}</option>
                @endforeach
            </select>

            <label>Select Employee:</label>
            <select name="employee_id" required>
                <option value="">-- Choose Employee --</option>
                @foreach ($employees as $employee)
                    <option value="{{ $employee->id }}">{{ $employee->user->name }}</option>
                @endforeach
            </select>

            <button type="submit">📎 Assign Customer</button>
        </form>
    </div>

    {{-- Show All Employees --}}
    <div class="section">
        <h2>All Employees</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($employees as $index => $employee)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $employee->user->name }}</td>
                        <td>{{ $employee->user->email }}</td>
                    </tr>
                @empty
                    <tr><td colspan="3">No employees found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- Show All Customers --}}
    <div class="section">
        <h2>All Customers</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Assigned Employee</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($customers as $index => $customer)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $customer->name }}</td>
                        <td>{{ $customer->email }}</td>
                        <td>{{ $customer->phone }}</td>
                        <td>
                            @if ($customer->employee)
                                {{ $customer->employee->user->name }}
                            @else
                                <em>Not Assigned</em>
                            @endif
                        </td>
                        <td>
                            {{-- Action Record Form --}}
                    

                            {{-- Display Customer Actions --}}
                            <div class="action-records">
                                <h4>Recent Actions</h4>
                                <ul>
                                    @foreach ($customer->actions as $action)
                                        <li>
                                            <span>{{ ucfirst($action->action_type) }}:</span> {{ $action->action_result }} <br>
                                            <small>Recorded on: {{ $action->created_at->format('d M Y, h:i A') }}</small>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="6">No customers found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

</body>
</html>
